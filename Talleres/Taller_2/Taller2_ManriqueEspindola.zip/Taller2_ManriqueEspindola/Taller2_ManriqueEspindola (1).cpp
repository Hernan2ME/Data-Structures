#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

// Definición del TAD Canción
struct Cancion {
    string titulo;
    string autor;
    string genero;
    string album;
    int año;
    int duracion;
    int calificacion;
};

// Definición del TAD Autor
struct Autor {
    string nombre;
    vector<Cancion> canciones;
};

// Definición del TAD Álbum
struct Album {
    string nombre;
    int año;
    vector<Cancion> canciones;
};

// Definición del TAD JaveMusic
struct JaveMusic {
    vector<Cancion> canciones;
    vector<Autor> autores;
    vector<Album> albums;
};

// Prototipos de funciones
void leerInformacionDesdeArchivo(JaveMusic& javeMusic, const string& nombreArchivo);
void listarAutores(const JaveMusic& javeMusic);
void listarCancionesPorAutor(const JaveMusic& javeMusic, const string& autor);
void listarAlbumes(const JaveMusic& javeMusic);
void listarCancionesPorAlbum(const JaveMusic& javeMusic, const string& album);
void listarCancionesYAlbumes(const JaveMusic& javeMusic);

int main() {
    JaveMusic javeMusic;
    string nombreArchivo = "canciones.txt"; // Nombre del archivo de entrada

    leerInformacionDesdeArchivo(javeMusic, nombreArchivo);

    int opcion;
    do {
        // Mostrar menú de opciones
        cout << "======= JaveMusic =======\n";
        cout << "1. Listar autores\n";
        cout << "2. Listar cacniones de X autor\n";
        cout << "3. Listar álbumes\n";
        cout << "4. Listar canciones de X álbum\n";
        cout << "5. Listar todas las canciones y su álbum\n";
        cout << "0. Salir\n";
        cout << "Ingrese una opción: ";
        cin >> opcion;

        switch (opcion) {
            case 1:
                listarAutores(javeMusic);
                break;
            case 2:
                {
                    string autor;
                    cout << "Ingrese el nombre del autor: ";
                    cin.ignore();
                    getline(cin, autor);
                    listarCancionesPorAutor(javeMusic, autor);
                }
                break;
            case 3:
                listarAlbumes(javeMusic);
                break;
            case 4:
                {
                    string album;
                    cout << "Ingrese el nombre del álbum: ";
                    cin.ignore();
                    getline(cin, album);
                    listarCancionesPorAlbum(javeMusic, album);
                }
                break;
            case 5:
                listarCancionesYAlbumes(javeMusic);
                break;
            case 0:
                cout << "Saliendo del programa...\n";
                break;
            default:
                cout << "Opción inválida. Intente nuevamente.\n";
                break;
        }

        cout << endl;
    } while (opcion != 0);

    return 0;
}

void leerInformacionDesdeArchivo(JaveMusic& javeMusic, const string& nombreArchivo) {
    ifstream archivo(nombreArchivo);
    if (!archivo) {
        cerr << "No se pudo abrir el archivo " << nombreArchivo << endl;
        exit(1);
    }

    int numCanciones;
    archivo >> numCanciones;

    for (int i = 0; i < numCanciones; ++i) {
        Cancion cancion;
        char separador;
        archivo.ignore();

        getline(archivo, cancion.titulo, '|');
        getline(archivo, cancion.autor, '|');
        getline(archivo, cancion.genero, '|');
        getline(archivo, cancion.album, '|');
        archivo >> cancion.año >> separador;
        javeMusic.canciones.push_back(cancion);

        // Buscar autor en la lista de autores
        auto it = find_if(javeMusic.autores.begin(), javeMusic.autores.end(), [&](const Autor& autor) {
            return autor.nombre == cancion.autor;
        });

        // Si no se encontró, agregar nuevo autor a la lista
        if (it == javeMusic.autores.end()) {
            Autor autor;
            autor.nombre = cancion.autor;
            autor.canciones.push_back(cancion);
            javeMusic.autores.push_back(autor);
        } else {
            // Si se encontró, agregar canción al autor existente
            it->canciones.push_back(cancion);
        }

        // Buscar álbum en la lista de álbumes
        auto albumIt = find_if(javeMusic.albums.begin(), javeMusic.albums.end(), [&](const Album& album) {
            return album.nombre == cancion.album;
        });

        // Si no se encontró, agregar nuevo álbum a la lista
        if (albumIt == javeMusic.albums.end()) {
            Album album;
            album.nombre = cancion.album;
            album.año = cancion.año;
            album.canciones.push_back(cancion);
            javeMusic.albums.push_back(album);
        } else {
            // Si se encontró, agregar canción al álbum existente
            albumIt->canciones.push_back(cancion);
        }
    }

    archivo.close();
}

void listarAutores(const JaveMusic& javeMusic) {
    cout << "Autores presentes:\n";
    for (const Autor& autor : javeMusic.autores) {
        cout << autor.nombre << endl;
    }
}

void listarCancionesPorAutor(const JaveMusic& javeMusic, const string& autor) {
    auto it = find_if(javeMusic.autores.begin(), javeMusic.autores.end(), [&](const Autor& a) {
        return a.nombre == autor;
    });

    if (it != javeMusic.autores.end()) {
        cout << "Canciones de " << autor << ":\n";
        for (const Cancion& cancion : it->canciones) {
            cout << cancion.titulo << " - " << cancion.album << endl;
        }
    } else {
        cout << "No se encontró el autor.\n";
    }
}

void listarAlbumes(const JaveMusic& javeMusic) {
    cout << "Álbumes presentes:\n";
    for (const Album& album : javeMusic.albums) {
        cout << album.nombre << " (" << album.año << ")\n";
    }
}

void listarCancionesPorAlbum(const JaveMusic& javeMusic, const string& album) {
    auto it = find_if(javeMusic.albums.begin(), javeMusic.albums.end(), [&](const Album& a) {
        return a.nombre == album;
    });

    if (it != javeMusic.albums.end()) {
        cout << "Canciones del álbum " << album << ":\n";
        for (const Cancion& cancion : it->canciones) {
            cout << cancion.titulo << endl;
        }
    } else {
        cout << "No se encontró el álbum.\n";
    }
}

void listarCancionesYAlbumes(const JaveMusic& javeMusic) {
    cout << "Canciones y sus álbumes:\n";
    for (const Cancion& cancion : javeMusic.canciones) {
        cout << cancion.titulo << " - " << cancion.album << endl;
    }
}