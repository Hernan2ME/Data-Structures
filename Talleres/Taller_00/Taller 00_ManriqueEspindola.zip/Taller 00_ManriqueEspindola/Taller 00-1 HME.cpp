//Hernán Manuel Manrique Espíndola
#include <iostream>
#include <cstdlib>

using namespace std;

int tam = 10;

int rand_num();

int main() {
  
  int arr_num[tam];
  
  for (int i = 0; i<tam; i++){
    arr_num[i] = rand_num();
  }

  int *punt;
  punt = arr_num;

  for(int k=0; k<tam; k++){
    cout <<"El elemento n " << k+1 << "Contiene " << *punt << "En la posición " << punt << endl;
    punt++;
  }

  delete punt;
  return 0;
}

int rand_num(){
  int num;
  num = rand() % 26;
  return num;
}