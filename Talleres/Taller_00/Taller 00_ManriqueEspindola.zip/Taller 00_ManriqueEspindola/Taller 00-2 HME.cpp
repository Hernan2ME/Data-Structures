#include <iostream>

using namespace std;

struct Cliente{
  string Nombre;
  int ID;
  string correo;
  int edad;
  
};

void crear (Cliente lista[], int tam);
void mostrar (Cliente lista[], int tam);


int main() {
  int tam, opc =3;
  char cont;
  
  Cliente clientes[tam]; 
  
  do{
    cout << "Ingrese la opción que desea ejecutar" << endl << "1. Ingresar los clientes." << endl << "2. Mostrar la lista de clientes" <<endl <<"3. Salir del programa"<< endl;
    cin >> opc;
    switch(opc){
      case 1:
        cout << "Ingrese la cantidad de clientes que desea agregar a la lista "<< endl;
        cin >> tam;
        crear(clientes, tam);
        break;
      case 2:
        mostrar(clientes, tam);
        break;
      default:
        return 0;
    }
      
    cout << "Desea repetir? (S/s || N/n)" << endl;
    cin >> cont;
    
  }while(cont != 'S' || cont != 's');
  
  return 0;
}

void crear (Cliente lista[], int tam){
  
Cliente* punt1 = &lista[0];
  
  for(int i=0; i<tam; i++){
    
    cout << "Ingrese la información del "<< i+1 << " cliente."<<endl;
    cout << "Ingrese el nombre del cliente -> ";
    cin >> punt1->Nombre;
    cout << "Ingrese el ID del cliente -> ";
    cin >> punt1->ID;
    cout << "Ingrese el correo del cliente -> ";
    cin >> punt1->correo;
    cout << "Ingrese la edad del cliente -> ";
    cin >> punt1->edad;
    
    punt1++;
  }
  
  delete punt1;
}

void mostrar (Cliente lista[], int tam){
  
  Cliente* punt2 = &lista[0];
  
  cout << "Lista de clientes"<<endl;
  for(int i=0; i<tam; i++){
    
    cout << "Cliente " << i+1 <<": " << endl;
    cout << "ID del cliente: " << punt2->ID;
    cout << "Nombre: " << punt2->Nombre;
    cout << "Edad del cliente: " << punt2->edad;
    cout << "Correo del cliente: " << punt2->correo;
    cout << endl;

    punt2++;
  }

  delete punt2;
}

