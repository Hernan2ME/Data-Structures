#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

// Estructura para representar un nodo del quadtree
struct QuadTreeNode {
    int value; // 0, 1 o 2
    QuadTreeNode* topLeft;
    QuadTreeNode* topRight;
    QuadTreeNode* bottomLeft;
    QuadTreeNode* bottomRight;

    QuadTreeNode(int val) : value(val), topLeft(nullptr), topRight(nullptr), bottomLeft(nullptr), bottomRight(nullptr) {}
};

// Función para construir el quadtree a partir del recorrido en preorden
QuadTreeNode* buildQuadTree(const string& preorder, int& index) {
    if (index >= preorder.length()) {
        return nullptr;
    }

    int val = preorder[index] - '0';
    QuadTreeNode* node = new QuadTreeNode(val);
    index++;

    if (val == 2) {
        node->topLeft = buildQuadTree(preorder, index);
        node->topRight = buildQuadTree(preorder, index);
        node->bottomLeft = buildQuadTree(preorder, index);
        node->bottomRight = buildQuadTree(preorder, index);
    }

    return node;
}

// Función auxiliar para generar la imagen PBM a partir del quadtree
void generatePBMImageHelper(const QuadTreeNode* node, vector<vector<int>>& image, int x, int y, int width, int height) {
    if (node == nullptr || width <= 0 || height <= 0) {
        return;
    }

    if (node->value == 0 || node->value == 1) {
        for (int i = y; i < y + height && i < image.size(); i++) {
            for (int j = x; j < x + width && j < image[i].size(); j++) {
                image[i][j] = node->value;
            }
        }
    } else {
        int halfWidth = width / 2;
        int halfHeight = height / 2;

        generatePBMImageHelper(node->topLeft, image, x, y, halfWidth, halfHeight);
        generatePBMImageHelper(node->topRight, image, x + halfWidth, y, halfWidth, halfHeight);
        generatePBMImageHelper(node->bottomLeft, image, x, y + halfHeight, halfWidth, halfHeight);
        generatePBMImageHelper(node->bottomRight, image, x + halfWidth, y + halfHeight, halfWidth, halfHeight);
    }
}

// Función para generar la imagen PBM a partir del quadtree
void generatePBMImage(const QuadTreeNode* root, int width, int height, ofstream& outFile) {
    outFile << "P1" << endl;
    outFile << "# Generated PBM Image" << endl;
    outFile << width << " " << height << endl;

    vector<vector<int>> image(height, vector<int>(width, 0));
    generatePBMImageHelper(root, image, 0, 0, width, height);

    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            outFile << image[i][j] << " ";
        }
        outFile << endl;
    }
}



int main(int argc, char* argv[]) {
    if (argc != 3) {
        cout << "Usage: ./program <preorder_file> <pbm_file>" << endl;
        return 1;
    }

    string preorderFile = argv[1];
    string pbmFile = argv[2];

    ifstream infile(preorderFile);
    if (!infile) {
        cout << "Failed to open " << preorderFile << endl;
        return 1;
    }

    string preorder;
    getline(infile, preorder);

    int width, height;
    infile >> width >> height;

    QuadTreeNode* root = nullptr;
    int index = 0;
    root = buildQuadTree(preorder, index);

    infile.close();

    ofstream outfile(pbmFile);
    if (!outfile) {
        cout << "Failed to create " << pbmFile << endl;
        return 1;
    }

    generatePBMImage(root, width, height, outfile);

    outfile.close();

    cout << "Image generated successfully." << endl;

    return 0;
}