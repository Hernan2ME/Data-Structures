
//LIBRERIAS NECESARIAS
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <cstring>
#include <sstream>
#include <cmath>
#include <map>







using namespace std;

//ESTRUCTURA DE COMANDOS DE MOVIMIENTO
struct ComandoMovimiento {
    string tipoMovimiento;
    double magnitud;
    string unidadMedida;
};

//ESTRCUTURA DE COMANDOS DE ANÁLISIS
struct ComandoAnalisis {
    string tipoAnalisis;
    string objeto;
    string comentario;
};

//ESTRUCTURA DE PUNTOS DE INTERES/ELEMENTOS
struct PuntoInteres {
    string tipoElemento;
    double tamaño;
    string unidadMedida;
    double coordenadaX;
    double coordenadaY;
};

struct Posicion {
    double x;
    double y;
};

struct JerarquiaElementos {
    std::map<std::string, std::vector<PuntoInteres>> elementos_por_tipo;
};


void mostrarParametros(const vector<string>& parametros) {
    for (const auto& parametro : parametros) {
      cout << parametro << "\n";
    }
    
  cout << endl;
}

//FUNCIONA PARA CARGAR DATOS DE ARCHIVO -> COMANDOS
void cargarComandos(const string& nombreArchivo, vector<ComandoMovimiento>& comandosMovimiento, vector<ComandoAnalisis>& comandosAnalisis) {
    ifstream archivo(nombreArchivo);

    //VERIFICAR QUE EL ARCHIVO ESTE ABIERTO
    if (!archivo.is_open()) {
        cout << "(Archivo erróneo) " << nombreArchivo << " no se encuentra o no puede leerse." << endl;
        return;
    }

    //LIMPIAR VECTORES DE COMANDOS
    comandosMovimiento.clear();
    comandosAnalisis.clear();

    int tipoComando;
    string p1, p2, p3;

    //lECTURA/PROCESO DE LINEAS DE ARCHIVO
    while (archivo >> tipoComando >> p1 >> p2 >> p3) {
        if (tipoComando == 0) {
            ComandoMovimiento comandoMovimiento;
            comandoMovimiento.tipoMovimiento = p1;
            comandoMovimiento.magnitud = stod(p2);
            comandoMovimiento.unidadMedida = p3;
            comandosMovimiento.push_back(comandoMovimiento);
        } else if (tipoComando == 1) {
            ComandoAnalisis comandoAnalisis;
            comandoAnalisis.tipoAnalisis = p1;
            comandoAnalisis.objeto = p2;
            comandoAnalisis.comentario = p3;
            comandosAnalisis.push_back(comandoAnalisis);
        }
    }
  
    //VERIFICAR SI EL ARCHIVO ESTA VACIO
    if (comandosMovimiento.empty() && comandosAnalisis.empty()) {
        cout << "(Archivo vacío) " << nombreArchivo << " no contiene comandos." << endl;
    } else {
        int totalComandos = comandosMovimiento.size() + comandosAnalisis.size();
        cout << endl << "(Resultado exitoso) " << totalComandos << " comandos cargados correctamente desde " << nombreArchivo << "." << endl;
    }
    archivo.close();
}

//FUNCIÓN PARA CARGAR ELEMENTOS DE ARCHIVO
void cargarElementos(const string& nombreArchivo, vector<PuntoInteres>& puntosInteres) {
    //APERTURA DEL ARCHIVO
    ifstream archivo(nombreArchivo);

    //VERIFICAR SI EL ARCHIVO SE PUDO ABRIR
    if (!archivo) {
        cout << "(Archivo erróneo) " << nombreArchivo << " no se encuentra o no puede leerse." << endl;
        return;
    }

    //LIMPIAR VECTORS
    puntosInteres.clear();

    string tipoElemento;
    double tamaño;
    string unidadMedida;
    double coordenadaX;
    double coordenadaY;

    //LECTURA Y ALMACENAMIENTO DE ELEMENTOS
    while (archivo >> tipoElemento >> tamaño >> unidadMedida >> coordenadaX >> coordenadaY) {
        PuntoInteres puntoInteres;
        puntoInteres.tipoElemento = tipoElemento;
        puntoInteres.tamaño = tamaño;
        puntoInteres.unidadMedida = unidadMedida;
        puntoInteres.coordenadaX = coordenadaX;
        puntoInteres.coordenadaY = coordenadaY;
        puntosInteres.push_back(puntoInteres);
    }


    archivo.close();

    cout << "(Resultado exitoso) " << puntosInteres.size() << " elementos cargados correctamente desde " << nombreArchivo << "." << endl;
}


//FUNCION PARA AÑADIR MOVIMIENTOS
void agregarMovimiento(const string& tipoMovimiento, const string& magnitud, const string& unidadMedida, vector<ComandoMovimiento>& comandosMovimiento) {
  
    //VERIFICAR QUE SEA UN MOVIMIENTO VALIDO
    if (tipoMovimiento != "avanzar" && tipoMovimiento != "girar") {
        cout << "(Formato erróneo) La información del movimiento no corresponde a los datos esperados (tipo, magnitud, unidad)." << endl;
        return;
    }

    //AGREGAR NUEVO COMANDO A LA LISTA
    ComandoMovimiento comandoMovimiento;
    comandoMovimiento.tipoMovimiento = tipoMovimiento;
    comandoMovimiento.magnitud = stod(magnitud);
    comandoMovimiento.unidadMedida = unidadMedida;
    comandosMovimiento.push_back(comandoMovimiento);

 
    cout << "(Resultado exitoso) El comando de movimiento ha sido agregado exitosamente." << endl;
}


//FUNCION PARA AÑADIR ANALISIS
void agregarAnalisis(const string& tipoAnalisis, const string& objeto, const string& comentario, vector<ComandoAnalisis>& comandosAnalisis) {
  
    //VERIFICAR QUE SEA UN TIPO DE ANALISIS VALIDO
    if (tipoAnalisis != "fotografiar" && tipoAnalisis != "composicion" && tipoAnalisis != "perforar") {
        cout << "(Formato erróneo) La información del análisis no corresponde a los datos esperados (tipo, objeto, comentario)." << endl;
        return;
    }

    //AGREGAR NUEVO COMANDO A LA LISTA
    ComandoAnalisis comandoAnalisis;
    comandoAnalisis.tipoAnalisis = tipoAnalisis;
    comandoAnalisis.objeto = objeto;
    comandoAnalisis.comentario = comentario;
    comandosAnalisis.push_back(comandoAnalisis);

    cout << "(Resultado exitoso) El comando de análisis ha sido agregado exitosamente." << endl;
}


//FUNCION PARA AGREGAR ELEMENTOS
void agregarElemento(const string& tipoElemento, const string& tamaño, const string& unidadMedida, const string& coordenadaX, const string& coordenadaY, vector<PuntoInteres>& puntosInteres) {
    
    //AGREGAR NUEVO ELEMENTO A LA LISTA
    PuntoInteres puntoInteres;
    puntoInteres.tipoElemento = tipoElemento;
    puntoInteres.tamaño = stod(tamaño);
    puntoInteres.unidadMedida = unidadMedida;
    puntoInteres.coordenadaX = stod(coordenadaX);
    puntoInteres.coordenadaY = stod(coordenadaY);

    puntosInteres.push_back(puntoInteres);

    
  cout << "(Resultado exitoso) El elemento ha sido agregado exitosamente." <<   endl;
}


//FUNCION PARA GURADAR COMANDOS EN ARCHIVO
void guardarComandos(const string& nombreArchivo, const vector<ComandoMovimiento>& movimientos, const vector<ComandoAnalisis>& analisis) {

    //APERTURA/CREACIÓN DEL ARCHIVO
    ofstream archivo(nombreArchivo);
    
    for(int j=0; j < movimientos.size();j++){
      cout << movimientos[j].tipoMovimiento << endl;
    }

    //INGRESO DE INFORMACION AL AECHIVO
    if (archivo.is_open()) {
        for (const auto& movimiento : movimientos) {
            archivo << "0" << movimiento.tipoMovimiento << " " << movimiento.magnitud << " " << movimiento.unidadMedida << "\n";
        }

        for (const auto& analisis : analisis) {
            archivo << "1" << analisis.tipoAnalisis << " " << analisis.objeto << " " << analisis.comentario << "\n";
        }

        archivo.close();
        cout << "(Escritura exitosa) La información ha sido guardada en " << nombreArchivo << "." << endl;
    } else {
        cout << "(Problemas en archivo) Error guardando en " << nombreArchivo << "." << endl;
    }
}


//FUNCION PARA GUARDAR ELEMNTOS EN ARCHIVO
void guardarElementos(const string& nombreArchivo, const vector<PuntoInteres>& elementos) {
    
    //APERTURA/CREACION DEL ARCHIVO
    ofstream archivo(nombreArchivo);

    //INGRESO DE INFORMACIÓN AL ARCHIVO
    if (archivo.is_open()) {
        for (const auto& elemento : elementos) {
            archivo << "Elemento: " << elemento.tipoElemento << " " << elemento.tamaño << " " << elemento.unidadMedida << " "
                    << elemento.coordenadaX << " " << elemento.coordenadaY << "\n";
        }

        archivo.close();
        cout << "(Escritura exitosa) La información ha sido guardada en " << nombreArchivo << "." << endl;
    } else {
        cout << "(Problemas en archivo) Error guardando en " << nombreArchivo << "." << endl;
    }
}


//FUNCION DE SIMULACION DE COMANDOS
void simularComandos(const vector<ComandoMovimiento>& comandosMovimiento, const Posicion& posicionActual) {
    if (comandosMovimiento.empty()) {
        cout << "(No hay información) La información requerida no está almacenada en memoria." << endl;
        return;
    }

    double nuevoX = posicionActual.x;
    double nuevoY = posicionActual.y;
    double angulo = 0.0;

    
    for (const auto& movimiento : comandosMovimiento) {
        if (movimiento.tipoMovimiento == "avanzar") {
          
            //SIMULACIÓN DE DESPLAZAMIENTO 
            if (movimiento.unidadMedida == "metros") {
                nuevoX += movimiento.magnitud * cos(angulo);
                nuevoY += movimiento.magnitud * sin(angulo);
            } else if (movimiento.unidadMedida == "metros") {
                nuevoX += movimiento.magnitud * 1000 * cos(angulo);
                nuevoY += movimiento.magnitud * 1000 * sin(angulo);
            } else {
                cout << "(Formato erróneo) Unidad de medida desconocida: " << movimiento.unidadMedida << endl;
                return;
            }
        } else if (movimiento.tipoMovimiento == "girar") {
          
            //SIMULACIÓN DE ROTACIÓN
            if (movimiento.unidadMedida == "grados") {
                double anguloRadianes = movimiento.magnitud * M_PI / 180.0;
                angulo += anguloRadianes;
            } else {
                cout << "(Formato erróneo) Unidad de medida desconocida: " << movimiento.unidadMedida << endl;
                return;
            }
        } else {
            cout << "(Formato erróneo) Tipo de movimiento desconocido: " << movimiento.tipoMovimiento << endl;
            return;
        }
    }

    //RESULTADOS
    cout << "(Resultado exitoso) La simulación de los comandos, a partir de la posición (" << posicionActual.x << ","
              << posicionActual.y << "), deja al robot en la nueva posición (" << nuevoX << "," << nuevoY << ")." << endl;
}


//FUNCION DE PROCESAMIENTO DE ELEMENTOS Y ORGANIZACION JERARQUICAMENTE
void ubicarElementos(std::vector<PuntoInteres>& elementos, JerarquiaElementos& jerarquia) {
    if (elementos.empty()) {
        std::cout << "(No hay información) La información requerida no está almacenada en memoria.\n";
        return;
    }

    std::vector<PuntoInteres> elementosNoProcesados;

    //UBICAR ELEMENTOS EN ESTRUCTURA JERARQUICA
    for (const PuntoInteres& elemento : elementos) {
      
        // TIPO DE ELEMENTO
        std::string tipo = elemento.tipoElemento;

        //SI NO ES VALIDO, A ESTRCUTURA CORRESPONDIENTE
        if (tipo == "roca" || tipo == "crater" || tipo == "monticulo" || tipo == "duna") {
            jerarquia.elementos_por_tipo[tipo].push_back(elemento);
        } else {
            elementosNoProcesados.push_back(elemento);
        }
    }

    //MOSTRAR UBICACION
    for (const auto& tipo_elementos : jerarquia.elementos_por_tipo) {
        const std::string& tipo = tipo_elementos.first;
        const std::vector<PuntoInteres>& elementos_tipo = tipo_elementos.second;

        std::cout << "Elementos del tipo " << tipo << ":\n";
        for (const PuntoInteres& elemento : elementos_tipo) {
            std::cout << "- Tamaño: " << elemento.tamaño << " " << elemento.unidadMedida << ", Coordenadas: (" << elemento.coordenadaX << ", " << elemento.coordenadaY << ")\n";
        }
        std::cout << "\n";
    }

    //IMPRIMIR ELEMENTOS NO PROCESADOS
    if (!elementosNoProcesados.empty()) {
        std::cout << "(Problemas con elementos) Los siguientes elementos no pudieron procesarse adecuadamente:\n";
        for (const PuntoInteres& elemento : elementosNoProcesados) {
            std::cout << "- Tipo: " << elemento.tipoElemento << ", Tamaño: " << elemento.tamaño<< ", Unidad: " << elemento.unidadMedida << ", Coordenadas: (" << elemento.coordenadaX << ", " << elemento.coordenadaY << ")\n";
        }
    }

    std::cout << "(Resultado exitoso) Los elementos han sido procesados exitosamente.\n";
}

/*
void enCuadrante(double coordX1, double coordX2, double coordY1, double coordY2, const JerarquiaElementos& jerarquia) {
    // Verificar el formato de los límites del cuadrante
    if (coordX1 >= coordX2 || coordY1 >= coordY2) {
        std::cout << "(Formato erróneo) La información del cuadrante no corresponde a los datos esperados (x_min, x_max, y_min, y_max)." << std::endl;
        return;
    }

    // Verificar si los elementos han sido ubicados previamente
    if (jerarquia.empty()) {
        std::cout << "(No hay información) Los elementos no han sido ubicados todavía (con el comando ubicar_elementos)." << std::endl;
        return;
    }

    // Realizar la búsqueda de elementos en el cuadrante
    std::vector<Elemento> elementosEnCuadrante;
    for (const Elemento& elemento : jerarquia) {
        if (elemento.coordenadaX >= coordX1 && elemento.coordenadaX <= coordX2 &&
            elemento.coordenadaY >= coordY1 && elemento.coordenadaY <= coordY2) {
            elementosEnCuadrante.push_back(elemento);
        }
    }

    // Mostrar los elementos encontrados en el cuadrante
    if (elementosEnCuadrante.empty()) {
        std::cout << "(Resultado exitoso) No se encontraron elementos en el cuadrante solicitado." << std::endl;
    } else {
        std::cout << "(Resultado exitoso) Los elementos ubicados en el cuadrante solicitado son:" << std::endl;
        for (const Elemento& elemento : elementosEnCuadrante) {
            std::cout << "Tipo: " << elemento.tipoElemento << ", Tamaño: " << elemento.tamano
                      << ", Unidad de medida: " << elemento.unidadMedida << ", Coordenadas: (" << elemento.coordenadaX
                      << ", " << elemento.coordenadaY << ")" << std::endl;
        }
    }
}
*/

//MAIN
int main() {

  bool ComF = true;
  
  vector<string> ComandosLista = {"mostrar_comandos", "cargar_comandos", "cargar_elementos", "agregar_movimiento", "agregar_analisis", "agregar_elemento", "guardar", "simular_comandos", "salir", "ubicar_elementos", "en_cuadrante", "crear_mapa", "ruta_mas_larga"};
  vector<string> mostrarC_parametros = { "cargar_comandos", "cargar_elementos", "agregar_movimiento", "agregar_analisis", "agregar_elemento", "guardar", "simular_comandos", "salir", "ubicar_elementos", "en_cuadrante", "crear_mapa", "ruta_mas_larga" };
  vector<string> cargarC_parametros = { "nombre_archivo" };
  vector<string> cargarE_parametros = { "nombre_archivo" };
  vector<string> agregarM_parametros = { "tipo_mov", "magnitud", "unidad_med" };
  vector<string> agregarA_parametros = { "tipo_analisis", "objeto", "comentario" };
  vector<string> agregarE_parametros = { "tipo_comp", "tamaño", "unidad_med", "coordX", "coordY" };
  vector<string> guardar_parametros = { "tipo_archivo", "nombre_archivo" };
  vector<string> simularC_parametros = { "coordX", "coordY" };
  vector<string> salir_parametros = { "Ninguno :D" };
  vector<string> ubicarE_parametros = { "Ninguno :D" };
  vector<string> enC_parametros = { "coordX1", "coordX2", "coordY1", "coordY2" };
  vector<string> crearM_parametros = { "coeficiente_conectividad" };
  vector<string> rutaMl_parametros = { "Ninguno :D" };

  vector<ComandoMovimiento> comandosMovimiento;
  vector<ComandoAnalisis> comandosAnalisis;
  vector<PuntoInteres> puntosInteres;

  JerarquiaElementos jerarquia;

  Posicion posicionActual;


    string line;
    string tok;
    vector<string> arguments;

    cout << "Comando y parámetros: ";
    cin >> line;

    stringstream ss(line);
    while (getline(ss, tok, ' ')) {
        arguments.push_back(tok);
    }

  string comando = arguments[1];
  while(ComF){
    if (comando == "mostrar_comandos") {
        if (arguments.size() < 2) {
          cout << "El comando 'mostrar_comandos' requiere los siguientes parámetros:" << 
              endl;
            mostrarParametros(mostrarC_parametros);
             
        }
    
    }
    else if (comando == "cargar_comandos") {
        if (arguments.size() < 2) {
            
          cout << "El comando 'cargar_comandos' requiere los siguientes parámetros:" << endl;
            mostrarParametros(cargarC_parametros);
            
          
        }else{
          
          //CARGA DE COMANDOS
          cargarComandos(arguments[2], comandosMovimiento, comandosAnalisis);
          
          //CONTENIDO CARGADO
          cout << endl;
          cout << "MOVIMIENTO" << endl;
          for(int j =0; j < comandosMovimiento.size(); j++){
            cout << comandosMovimiento[j].tipoMovimiento << " " << comandosMovimiento[j].magnitud << " " << comandosMovimiento[j].unidadMedida << endl;
          }
          cout << endl << "ANALISIS" << endl;
          for(int j = 0 ; j < comandosAnalisis.size(); j++){
            cout << comandosAnalisis[j].tipoAnalisis << " " << comandosAnalisis[j].objeto << " " << comandosAnalisis[j].comentario << endl;
          }
        }
    }
      
    
      else if(comando == "cargar_elementos"){
        if (arguments.size() < 2) {
          cout << "El comando 'cargar_elementos' requiere los siguientes parámetros:" << 
              endl;
            mostrarParametros(cargarE_parametros);
        }
        else{

          //CARGA DE ELEMENTOS
           cargarElementos(arguments[2], puntosInteres);

          //CONTENIDO CARGADO
          cout << "ELEMENTOS/PUNTOS_DE_INTERES" << endl;
          for(int j = 0; j < puntosInteres.size(); j++){
            cout << puntosInteres[j].tipoElemento << " " << puntosInteres[j].tamaño << " " << puntosInteres[j].unidadMedida << " " << puntosInteres[j].coordenadaX << " " << puntosInteres[j].coordenadaY << endl;
          }          
        }
      }
        else if (comando == "agregar_movimiento"){
          if (arguments.size() < 2) {
            
            cout << "El comando 'agregar_movimiento' requiere los siguientes parámetros:" << endl;
              mostrarParametros(agregarM_parametros);
              
            
          }else{

            //ADICION DE COMANDO MOVIMIENTO
             agregarMovimiento(arguments[2], arguments[3], arguments[4], comandosMovimiento);
             cout << endl;

            //LISTADP ACTUALIZADO
            cout << "MOVIMIENTO" << endl;
            for(int j =0; j < comandosMovimiento.size(); j++){
              cout << comandosMovimiento[j].tipoMovimiento << " " << comandosMovimiento[j].magnitud << " " << comandosMovimiento[j].unidadMedida << endl;
            }
          }
        }
          else if (comando == "agregar_analisis"){
            if (arguments.size() < 2) {
            
              cout << "El comando 'agregar_analisis' requiere los siguientes parámetros:" << 
                  endl;
                mostrarParametros(agregarA_parametros);
            }
            else{

              //ADICIÓN DE COMANDO ANALISIS
              agregarAnalisis(arguments[2], arguments[3], arguments[4], comandosAnalisis);

              //LISTADO ACTUALIZADO
              cout << endl << "ANALISIS" << endl;
              for(int j = 0 ; j < comandosAnalisis.size(); j++){
                cout << comandosAnalisis[j].tipoAnalisis << " " << comandosAnalisis[j].objeto << " " << comandosAnalisis[j].comentario << endl;
              } 
            }
          }
            else if (comando == "agregar_elemento"){
              if (arguments.size() < 2) {
            
                cout << "El comando 'agregar_elemento' requiere los siguientes parámetros:" << 
                    endl;
                  mostrarParametros(agregarE_parametros);               
              }
              else{
                
                //ADICION DE ELEMENTOS
                agregarElemento(arguments[2], arguments[3], arguments[4], arguments[5], arguments[6], puntosInteres);
              }
            }
              else if (comando == "guardar"){
                if (arguments.size() < 2) {
            
                  cout << "El comando 'guardar' requiere los siguientes parámetros:" << 
                      endl;
                    mostrarParametros(guardar_parametros);
                }
                else{

                  //GUARDADO DE COMANDOS / ELEMENTOS
                  if (arguments[2] == "comandos") {
                    guardarComandos(arguments[3], comandosMovimiento, comandosAnalisis);
                  } else if (arguments[2] == "elementos") {
                    guardarElementos(arguments[3], puntosInteres);
                  } else {
                     cout << "Tipo de archivo inválido." << endl;
                  }
                }
              }
                else if (comando == "simular_comandos"){
                  if (arguments.size() < 2) {
            
                    cout << "El comando 'simular_comandos' requiere los siguientes parámetros:" << 
                        endl;
                      mostrarParametros(simularC_parametros);
                  }

                    //SIMULACION DE COMANDO MOVIMIENTO E INGRESO DE COORDENADAS
                  else{
                    cout << "Ingrese la posición actual del robot:" << endl;
                    cout << "Coordenada X: ";
                    cin >> posicionActual.x;
                    cout << "Coordenada Y: ";
                    cin >> posicionActual.y;

                    simularComandos(comandosMovimiento, posicionActual);
                  }
                }
                  else if (comando == "salir"){
                    if (arguments.size() < 2) {
            
                      cout << "El comando 'salir' requiere los siguientes parámetros:" << 
                          endl;
                        mostrarParametros(salir_parametros);
                    }

                      //SALIDA DEL PROGRAMA
                      continue;
                  }
                    else if (comando == "ubicar_elementos"){
                      if (arguments.size() < 2) {
            
                        cout << "El comando 'ubicar_elementos' requiere los siguientes parámetros:" << 
                            endl;
                          mostrarParametros(ubicarE_parametros);                       
                      }
                        else{

                          //UBICAR ELEMENTOS
                          ubicarElementos(puntosInteres, jerarquia);
                        }
                    }
                      else if (comando == "en_cuadrante"){
                        if (arguments.size() < 2) {
            
                          cout << "El comando 'en_cuadrante' requiere los siguientes parámetros:" << 
                              endl;
                            mostrarParametros(enC_parametros);
                        }
                          else{

                            int X1, X2, Y1, Y2;
                            cout << "Cuadrante en X1: ";
                            cin >> X1;
                            cout << "\nCuadrante en Y1: ";
                            cin >> Y1;
                            cout << "\nCuadrante en X2: ";
                            cin >> X2;
                            cout << "\nCuadrante en Y2: ";
                            cin >> Y2;

                            //enCuadrante(X1, X2, Y1, Y2, jerarquia);
                            
                          }
                        
                      }
                        else if (comando == "crear_mapa"){
                          if (arguments.size() < 2) {
            
                            cout << "El comando 'crear_mapa' requiere los siguientes parámetros:" << 
                                endl;
                              mostrarParametros(crearM_parametros);
                              
                            
                          }

                          for(int i = 1; i < arguments.size(); i++){
                            cout << "Argumento " << i << ": " << arguments[i + 1] <<endl;
                            
                            
                          }
                          
                        }
                          else if (comando == "ruta_mas_larga"){
                            if (arguments.size() < 2) {
            
                              cout << "El comando 'ruta_mas_larga' requiere los siguientes parámetros:" << 
                                  endl;
                                mostrarParametros(rutaMl_parametros);
                                
                              
                            }  
                            
                            for(int i = 1; i < arguments.size(); i++){
                              cout << "Argumento " << i << ": " << arguments[i + 1] <<endl;
                              
                              
                            }
                            
                          }
    else {
      ComF = false;
    }
    if (ComF == false){
      cout << "Comando desconocido: " << comando << 
          endl;
        
      
    }
    
}
  
    


    return 0;
}