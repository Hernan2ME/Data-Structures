
//LIBRERIAS NECESARIAS
#include <iostream>
#include <string>
#include <vector>

using namespace std;

//FUNCIÓN PARA MOSTRAR LOS PARÁMETROS NECESITADOS POR CADA COMANDO
void mostrarParametros(const vector<string>& parametros) {
    for (const auto& parametro : parametros) {
      cout << parametro << "\n";
    }
    
  cout << endl;
}

//MAIN
int main(int argc, char* argv[]) {

  //VALIDACIÓN NECESARIA PARA SABER SI EL COMANDO HA SIDO RECONOCIDO
  bool ComF = true;

  
//DEFINICIÓN DE LOS COMANDOS EXISTENTES Y LOS PARÁMETROS QUE REQUIEREN
  
  vector<string> ComandosLista = {"mostrar_comandos", "cargar_comandos", "cargar_elementos", "agregar_movimiento", "agregar_analisis", "agregar_elemento", "guardar", "simular_comandos", "salir", "ubicar_elementos", "en_cuadrante", "crear_mapa", "ruta_mas_larga"};
  vector<string> mostrarC_parametros = { "cargar_comandos", "cargar_elementos", "agregar_movimiento", "agregar_analisis", "agregar_elemento", "guardar", "simular_comandos", "salir", "ubicar_elementos", "en_cuadrante", "crear_mapa", "ruta_mas_larga" };
  vector<string> cargarC_parametros = { "nombre_archivo" };
  vector<string> cargarE_parametros = { "nombre_archivo" };
  vector<string> agregarM_parametros = { "tipo_mov", "magnitud", "unidad_med" };
  vector<string> agregarA_parametros = { "tipo_analisis", "objeto", "comentario" };
  vector<string> agregarE_parametros = { "tipo_comp", "tamaño", "unidad_med", "coordX", "coordY" };
  vector<string> guardar_parametros = { "tipo_archivo", "nombre_archivo" };
  vector<string> simularC_parametros = { "coordX", "coordY" };
  vector<string> salir_parametros = { "Ninguno :D" };
  vector<string> ubicarE_parametros = { "Ninguno :D" };
  vector<string> enC_parametros = { "coordX1", "coordX2", "coordY1", "coordY2" };
  vector<string> crearM_parametros = { "coeficiente_conectividad" };
  vector<string> rutaMl_parametros = { "Ninguno :D" };

  

    //SI NO SE INTRODUCE NINGÚN COMANDO, SE MUESTRA LA LISTA DE LOS MISMOS
  
    if (argc < 2) {
        
      cout << "Se requiere un comando." << endl;
      cout << endl << "Comandos Disponibles:" << "\n";
      for(int i = 0; i < ComandosLista.size(); i++){
        cout << ComandosLista[i] << "\n";
      }
        return 1;
    }

 //SE ACCEDE A LOS COMANDOS QUE SON VALIDOS, EN CASO DE NO INTRUCIR PARÁMETROS MOSTRARÁ LOS PARÁMETROS NECESITADOS PARA EJECUTAR CADA COMANDO
  //EN EL CASO QUE SE INTRODUZCAN LOS PARÁMETROS, MUESTRA QUE PARÁMETROS FUERON INTRODUCIDOS
  string comando = argv[1];
  for(int i = 0; i < ComandosLista.size(); i++){
    if (comando == "mostrar_comandos") {
        if (argc < 2 + mostrarC_parametros.size()) {
          cout << "El comando 'mostrar_comandos' requiere los siguientes parámetros:" << 
              endl;
            mostrarParametros(mostrarC_parametros);
            return 1;
        }
     
    }
    else if (comando == "cargar_comandos") {
        if (argc < 2 + cargarC_parametros.size()) {
            
          cout << "El comando 'cargar_comandos' requiere los siguientes parámetros:" << endl;
            mostrarParametros(cargarC_parametros);
            return 1;
        }
      
        for(int i = 1; i < argc; i++){
          cout << "Argumento " << i << ": " << argv[i + 1] <<endl;
          return 1;
        }
      
    }
      else if(comando == "cargar_elementos"){
        if (argc < 2 + cargarE_parametros.size()) {
            
          cout << "El comando 'cargar_elementos' requiere los siguientes parámetros:" << 
              endl;
            mostrarParametros(cargarE_parametros);
            return 1;
        }

        for(int i = 1; i < argc; i++){
          cout << "Argumento " << i << ": " << argv[i + 1] <<endl;
          return 1;
        }
        
      }
        else if (comando == "agregar_movimiento"){
          if (argc < 2 + agregarM_parametros.size()) {
            
            cout << "El comando 'agregar_movimiento' requiere los siguientes parámetros:" << endl;
              mostrarParametros(agregarM_parametros);
              return 1;
          }

          for(int i = 1; i < argc; i++){
            cout << "Parámetro " << i << ": " << argv[i + 1] <<endl;
            return 1;
          }
          
        }
          else if (comando == "agregar_analisis"){
            if (argc < 2 + agregarA_parametros.size()) {
            
              cout << "El comando 'agregar_analisis' requiere los siguientes parámetros:" << 
                  endl;
                mostrarParametros(agregarA_parametros);
                return 1;
            }

            for(int i = 1; i < argc; i++){
              cout << "Argumento " << i << ": " << argv[i + 1] <<endl;
              return 1;
            }
            
          }
            else if (comando == "agregar_elemento"){
              if (argc < 2 + agregarE_parametros.size()) {
            
                cout << "El comando 'agregar_elemento' requiere los siguientes parámetros:" << 
                    endl;
                  mostrarParametros(agregarE_parametros);
                  return 1;
              }

              for(int i = 1; i < argc; i++){
                cout << "Argumento " << i << ": " << argv[i + 1] <<endl;
                return 1;
              }
              
            }
              else if (comando == "guardar"){
                if (argc < 2 + guardar_parametros.size()) {
            
                  cout << "El comando 'guardar' requiere los siguientes parámetros:" << 
                      endl;
                    mostrarParametros(guardar_parametros);
                    return 1;
                }

                for(int i = 1; i < argc; i++){
                  cout << "Argumento " << i << ": " << argv[i + 1] <<endl;
                  return 1;
                }
                
              }
                else if (comando == "simular_comandos"){
                  if (argc < 2 + simularC_parametros.size()) {
            
                    cout << "El comando 'simular_comandos' requiere los siguientes parámetros:" << 
                        endl;
                      mostrarParametros(simularC_parametros);
                      return 1;
                  }

                  for(int i = 1; i < argc; i++){
                    cout << "Argumento " << i << ": " << argv[i + 1] <<endl;
                    return 1;
                  }
                  
                }
                  else if (comando == "salir"){
                    if (argc < 2 + salir_parametros.size()) {
            
                      cout << "El comando 'salir' requiere los siguientes parámetros:" << 
                          endl;
                        mostrarParametros(salir_parametros);
                        return 1;
                    }

                    for(int i = 1; i < argc; i++){
                      cout << "Argumento " << i << ": " << argv[i + 1] <<endl;
                      return 1;
                    }
                    
                  }
                    else if (comando == "ubicar_elementos"){
                      if (argc < 2 + ubicarE_parametros.size()) {
            
                        cout << "El comando 'ubicar_elementos' requiere los siguientes parámetros:" << 
                            endl;
                          mostrarParametros(ubicarE_parametros);
                          return 1;
                      }

                      for(int i = 1; i < argc; i++){
                        cout << "Argumento " << i << ": " << argv[i + 1] <<endl;
                        return 1;
                      }
                      
                    }
                      else if (comando == "en_cuadrante"){
                        if (argc < 2 + enC_parametros.size()) {
            
                          cout << "El comando 'en_cuadrante' requiere los siguientes parámetros:" << 
                              endl;
                            mostrarParametros(enC_parametros);
                            return 1;
                        }

                        for(int i = 1; i < argc; i++){
                          cout << "Argumento " << i << ": " << argv[i + 1] <<endl;
                          return 1;
                        }
                        
                      }
                        else if (comando == "crear_mapa"){
                          if (argc < 2 + crearM_parametros.size()) {
            
                            cout << "El comando 'crear_mapa' requiere los siguientes parámetros:" << 
                                endl;
                              mostrarParametros(crearM_parametros);
                              return 1;
                          }

                          for(int i = 1; i < argc; i++){
                            cout << "Argumento " << i << ": " << argv[i + 1] <<endl;
                            return 1;
                          }
                          
                        }
                          else if (comando == "ruta_mas_larga"){
                            if (argc < 2 + rutaMl_parametros.size()) {
            
                              cout << "El comando 'ruta_mas_larga' requiere los siguientes parámetros:" << 
                                  endl;
                                mostrarParametros(rutaMl_parametros);
                                return 1;
                            }  
                            
                            for(int i = 1; i < argc; i++){
                              cout << "Argumento " << i << ": " << argv[i + 1] <<endl;
                              return 1;
                            }
                            
                          }
    else {
      ComF = false;
    }

    
  }
  
  //SI NO SE RECONOCE EL COMANDO LO INDICA
    if (ComF == false){
      cout << "Comando desconocido: " << comando << 
          endl;
        return 1;
    }


    return 0;
}